#pragma once
#include <cstdint>

namespace pkmn {
extern const uint8_t gBattleAI_Scripts[];
extern const uint32_t gBattleAI_ScriptsTable[];
} // namespace pkmn
